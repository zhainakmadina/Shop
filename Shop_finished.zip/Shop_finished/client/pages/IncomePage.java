package Shop.client.pages;

import Shop.client.applications.ApplicationButton;
import Shop.client.applications.ApplicationLabel;
import Shop.client.applications.ApplicationPanel;
import Shop.data.Device;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class IncomePage extends ApplicationPanel {
    public ClientFrame parent;
    private ApplicationButton backButton, refreshButton;
    private ApplicationLabel label, textLabel;
    private Object[] columns={"ID", "MODEL", "PRICE", "COUNT", "CPU", "RAM", "GOOD TYPE", "SOLD"};
    private JTable table;
    private DefaultTableModel model;
    private JScrollPane pane;
    private ArrayList<Device> devices;

    public IncomePage(ClientFrame parent) {
        this.parent = parent;
        table=new JTable();
        model=new DefaultTableModel();
        model.setColumnIdentifiers(columns);
        table.setModel(model);
        table.setBackground(Color.lightGray);
        table.setForeground(Color.black);
        table.setFont(new Font("Arial", 1, 16));
        table.setRowHeight(30);
        pane=new JScrollPane(table);
        pane.setBounds(0,0, 600, 400);
        add(pane);
        updateDevice();


        label=new ApplicationLabel("Total income: "+Integer.toString(getTotalPrice()));
        label.setBounds(400, 450, 300, 30);
        add(label);

        refreshButton=new ApplicationButton("REFRESH");
        refreshButton.setLocation(200, 500);
        add(refreshButton);
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                label.setText("Total income: "+Integer.toString(getTotalPrice()));
                clearDevice();
                updateDevice();
            }
        });

        backButton=new ApplicationButton("BACK");
        backButton.setLocation(200, 550);
        add(backButton);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parent.incomePage.setVisible(false);
                parent.adminPage.setVisible(true);
            }
        });

    }
    public void updateDevice(){
        devices=parent.clientSocket.getAllDevices();
        Object[] row=new Object[8];
        int total=0;
        for(Device d:devices){
            if(d.getSold()>0){
                row[0]=d.getId();
                row[1]=d.getModel();
                row[2]=d.getPrice();
                row[3]=d.getCount();
                row[4]=d.getCpu();
                row[5]=d.getRam();
                row[6]=d.getDevice_type();
                row[7]=d.getSold();
                model.addRow(row);
                //total+=d.getSold()*d.getPrice();
            }

        }
    }
    public int getTotalPrice(){
        devices=parent.clientSocket.getAllDevices();

        int total=0;
        for(Device d:devices){
            if(d.getSold()>0){
                total+=d.getSold()*d.getPrice();
            }
        }
        return total;
    }
    public void clearDevice(){
        DefaultTableModel dm = (DefaultTableModel)table.getModel();
        while(dm.getRowCount() > 0)
        {
            dm.removeRow(0);
        }
    }
}
