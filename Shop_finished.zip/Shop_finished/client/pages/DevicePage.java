package Shop.client.pages;

import Shop.client.applications.ApplicationButton;
import Shop.client.applications.ApplicationField;
import Shop.client.applications.ApplicationLabel;
import Shop.client.applications.ApplicationPanel;
import Shop.data.Device;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class DevicePage extends ApplicationPanel {
    private ClientFrame clientFrame;
    private ApplicationLabel idLabel, modelLabel, priceLabel, countLabel, cpuLabel, ramLabel, gtLabel;
    private ApplicationButton addButton, editButton, deleteButton, backButton, refreshButton;
    private ApplicationField idField, modelField, priceField, countField, cpuField, ramField;
    private String[] combo={"choose", "computer", "laptop", "tablet"};
    private Object[] columns={"ID", "MODEL", "PRICE", "COUNT", "CPU", "RAM", "GOOD TYPE"};
    private JComboBox jComboBox;
    private JTable table;
    private DefaultTableModel model;
    private JScrollPane pane;
    private ArrayList<Device> devices;

    public DevicePage(ClientFrame clientFrame) {
        this.clientFrame = clientFrame;
        table=new JTable();
        model=new DefaultTableModel();
        model.setColumnIdentifiers(columns);
        table.setModel(model);
        table.setBackground(Color.lightGray);
        table.setForeground(Color.black);
        table.setFont(new Font("Arial", 1, 16));
        table.setRowHeight(30);
        table.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int i=table.getSelectedRow();
                idField.setText(model.getValueAt(i,0).toString());
                modelField.setText(model.getValueAt(i,1).toString());
                priceField.setText(model.getValueAt(i,2).toString());
                countField.setText(model.getValueAt(i,3).toString());
                cpuField.setText(model.getValueAt(i,4).toString());
                ramField.setText(model.getValueAt(i,5).toString());
                jComboBox.setSelectedItem(model.getValueAt(i,6).toString());
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
        pane=new JScrollPane(table);
        pane.setBounds(0,0, 600, 400);
        add(pane);
        updateDevice();
        idLabel=new ApplicationLabel("ID");
        idLabel.setLocation(20, 420);
        add(idLabel);
        idField=new ApplicationField();
        idField.setLocation(150, 420);
        add(idField);

        modelLabel=new ApplicationLabel("Model:");
        modelLabel.setLocation(20, 460);
        add(modelLabel);
        modelField=new ApplicationField();
        modelField.setLocation(150, 460);
        add(modelField);

        priceLabel=new ApplicationLabel("Price:");
        priceLabel.setLocation(20, 500);
        add(priceLabel);
        priceField=new ApplicationField();
        priceField.setLocation(150, 500);
        add(priceField);

        countLabel=new ApplicationLabel("Count:");
        countLabel.setLocation(20, 540);
        add(countLabel);
        countField=new ApplicationField();
        countField.setLocation(150, 540);
        add(countField);

        cpuLabel=new ApplicationLabel("Cpu(string):");
        cpuLabel.setLocation(20, 580);
        add(cpuLabel);
        cpuField=new ApplicationField();
        cpuField.setLocation(150, 580);
        add(cpuField);

        ramLabel=new ApplicationLabel("Ram:");
        ramLabel.setLocation(20, 620);
        add(ramLabel);
        ramField=new ApplicationField();
        ramField.setLocation(150, 620);
        add(ramField);

        gtLabel=new ApplicationLabel("Good type:");
        gtLabel.setLocation(20, 660);
        add(gtLabel);

        jComboBox=new JComboBox(combo);
        jComboBox.setBounds(150, 660, 200, 30);
        jComboBox.setBackground(Color.green);
        jComboBox.setForeground(Color.black);
        jComboBox.setFont(new Font("Arial",1, 16));
        jComboBox.setBorder(new EtchedBorder(Color.black,Color.black));
        add(jComboBox);

        addButton=new ApplicationButton("ADD");
        addButton.setLocation(360, 450);
        add(addButton);
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String model=modelField.getText();
                int price=Integer.parseInt(priceField.getText());
                int count=Integer.parseInt(countField.getText());
                String cpu=cpuField.getText();
                int ram=Integer.parseInt(ramField.getText());
                String gt=jComboBox.getSelectedItem().toString();
                if(model.isEmpty() || cpu.isEmpty()){
                    JOptionPane.showMessageDialog(clientFrame, "Please, fill all fields!!!");
                }
                else{
                    Device device=new Device(null, model,price,count,cpu,ram,gt);
                    clientFrame.clientSocket.addDevice(device);
                    modelField.setText("");
                    priceField.setText("");
                    countField.setText("");
                    cpuField.setText("");
                    ramField.setText("");
                    jComboBox.setSelectedIndex(0);
                    JOptionPane.showMessageDialog(clientFrame, "Device is added successfully!!!");
                    clearDevice();
                    updateDevice();
                }
            }
        });

        editButton=new ApplicationButton("EDIT");
        editButton.setLocation(360, 500);
        add(editButton);
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Long id=Long.valueOf(idField.getText());
                String model=modelField.getText();
                int price=Integer.parseInt(priceField.getText());
                int count=Integer.parseInt(countField.getText());
                String cpu=cpuField.getText();
                int ram=Integer.parseInt(ramField.getText());
                String gt=jComboBox.getSelectedItem().toString();
                Device device=new Device(id, model, price, count, cpu, ram, gt);
                clientFrame.clientSocket.editDevice(device);
                clearDevice();
                updateDevice();
            }
        });

        deleteButton=new ApplicationButton("DELETE");
        deleteButton.setLocation(360, 550);
        add(deleteButton);
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Long id=Long.valueOf(idField.getText());
                Device device=new Device(id, null, 0, 0, null, 0 , null);
                clientFrame.clientSocket.deleteDevice(device);
                clearDevice();
                updateDevice();
            }
        });

        backButton=new ApplicationButton("BACK");
        backButton.setLocation(360, 600);
        add(backButton);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clientFrame.devicePage.setVisible(false);
                clientFrame.adminPage.setVisible(true);
            }
        });
        refreshButton=new ApplicationButton("Refresh");
        refreshButton.setLocation(360,650);
        add(refreshButton);
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearDevice();
                updateDevice();
            }
        });



    }
    public void updateDevice(){
        devices=clientFrame.clientSocket.getAllDevices();
        Object[] row=new Object[7];
        for(Device d:devices){
            row[0]=d.getId();
            row[1]=d.getModel();
            row[2]=d.getPrice();
            row[3]=d.getCount();
            row[4]=d.getCpu();
            row[5]=d.getRam();
            row[6]=d.getDevice_type();
            model.addRow(row);
        }
    }
    private void clearDevice(){
        DefaultTableModel dm = (DefaultTableModel)table.getModel();
        while(dm.getRowCount() > 0)
        {
            dm.removeRow(0);
        }
    }
}
