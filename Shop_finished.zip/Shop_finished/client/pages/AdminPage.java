package Shop.client.pages;

import Shop.client.applications.ApplicationButton;
import Shop.client.applications.ApplicationLabel;
import Shop.client.applications.ApplicationPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminPage extends ApplicationPanel {
    private ClientFrame parent;
    private ApplicationLabel label;
    private ApplicationButton deviceButton, clotheButton, incomeButton, logoutButton;
    public AdminPage(ClientFrame parent) {
        this.parent = parent;

        label=new ApplicationLabel("");
        label.setBounds(120, 120, 200, 50 );
        add(label);

        deviceButton=new ApplicationButton("DEVICES");
        deviceButton.setLocation(180, 200);
        add(deviceButton);
        deviceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parent.adminPage.setVisible(false);
                parent.devicePage.setVisible(true);
            }
        });

        clotheButton=new ApplicationButton("CLOTHES");
        clotheButton.setLocation(180, 260);
        add(clotheButton);

        incomeButton=new ApplicationButton("INCOME");
        incomeButton.setLocation(180, 320);
        add(incomeButton);
        incomeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parent.adminPage.setVisible(false);
                parent.incomePage.setVisible(true);
            }
        });

        logoutButton=new ApplicationButton("LOGOUT");
        logoutButton.setLocation(180, 380);
        add(logoutButton);
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ClientApp.currentUser=null;
                parent.adminPage.setVisible(false);
                parent.loginPage.setVisible(true);
            }
        });
    }
    public void updateData(){
        label.setText("Welcome "+ClientApp.currentUser.getFullname());
    }
}
