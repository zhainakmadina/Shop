package Shop.client.applications;

import javax.swing.*;
import java.awt.*;

public class ApplicationPanel extends JPanel {
    public ApplicationPanel(){
        setSize(600, 800);
        setLayout(null);
        setBackground(Color.white);
    }
}
