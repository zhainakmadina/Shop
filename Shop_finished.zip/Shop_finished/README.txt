Shop_finished
=============================

INSTALLATION
------------

Please make sure the release file is unpacked under a Web-accessible
directory. You shall see the following files and directories:

	client 		/client data have 2 folders
	data   		/data of shop
	server 		/server
	README 		/this file
	shop_db.sql	/database of project


REQUIREMENTS
------------

The minimum requirement is that your web server supports
Java/JDK/SQL. Shop has been tested with Apache HTTP server on Windows and Linux operating systems.


QUICK START
-----------
Open the zip file and unzip the data in it. 
Then you need to download the sql file and open it in phpmyadmin or Apache. 
Create a database with the same name as in the file, then upload the file to the application.
-----------

Zhainak Madina
zhainakmadina1@gmail.com
© 2022 GitHub, Inc.
Conditions
Privacy
