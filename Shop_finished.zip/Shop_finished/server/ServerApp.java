package Shop.server;

import Shop.data.Device;
import Shop.data.User;
import Shop.data.UserBuy;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.*;
import java.util.ArrayList;

public class ServerApp {
    public static Connection connection;
    public static void main(String args[]){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/shop_db?useUnicode=true&serverTimezone=UTC","root", "");
            ServerSocket serverSocket=new ServerSocket(2011);
            System.out.println("Waiting for a client...");
            while(true){
                Socket socket=serverSocket.accept();
                System.out.println("Client connected");
                ServerThread serverThread=new ServerThread(socket);
                serverThread.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void addUser(User user){
        try {
            PreparedStatement statement=connection.prepareStatement(""+
                    "INSERT INTO users(id, login, password, fullname, role)"+
                    " VALUES(null, ?, ?, ?, ?) ");
            statement.setString(1,user.getLogin());
            statement.setString(2,user.getPassword());
            statement.setString(3,user.getFullname());
            statement.setInt(4,user.getRole());
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void addUserBuy(UserBuy userBuy){
        try {
            PreparedStatement statement=connection.prepareStatement(""+
                    "INSERT INTO users_buy(id, user_id, good_type, count1, totalsum)"+
                    " VALUES(null, ?, ?, ?, ?) ");
            statement.setLong(1,userBuy.getUser_id());
            statement.setString(2,userBuy.getDevice_type());
            statement.setInt(3,userBuy.getCount());
            statement.setInt(4,userBuy.getTotalsum());
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static User getUser(String login, String password){
        User user=null;
        try {
            PreparedStatement statement=connection.prepareStatement("SELECT * FROM users where login=? and password=? ");
            statement.setString(1,login);
            statement.setString(2,password);
            ResultSet resultSet=statement.executeQuery();
            while(resultSet.next()){
                Long id=resultSet.getLong("id");
                String login1=resultSet.getString("login");
                String password1=resultSet.getString("password");
                String fullname=resultSet.getString("fullname");
                int role=resultSet.getInt("role");
                user=new User(id, login1, password1, fullname, role);
            }
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }
    public static void addDevice(Device device){
        try {
            PreparedStatement statement=connection.prepareStatement(""+
                    "INSERT INTO devices(id, model, price, count1, cpu, ram, device_type )"+
                    " VALUES(null, ?,?,?,?,?,?)");
            statement.setString(1,device.getModel());
            statement.setInt(2,device.getPrice());
            statement.setInt(3,device.getCount());
            statement.setString(4,device.getCpu());
            statement.setInt(5,device.getRam());
            statement.setString(6,device.getDevice_type());
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static ArrayList<Device> getAllDevices(){
        ArrayList<Device> devices=new ArrayList<>();
        try {
            PreparedStatement statement=connection.prepareStatement(""+
                    "SELECT * FROM devices");
            ResultSet resultSet=statement.executeQuery();
            while(resultSet.next()){
                Long id=resultSet.getLong("id");
                String model=resultSet.getString("model");
                int price=resultSet.getInt("price");
                int count=resultSet.getInt("count1");
                String cpu=resultSet.getString("cpu");
                int ram=resultSet.getInt("ram");
                String gt=resultSet.getString("device_type");
                int sold=resultSet.getInt("sold");
                devices.add(new Device(id, model, price, count,sold,cpu, ram, gt));
            }
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return devices;
    }

    public static Device getDevice(Long id){
        Device device=new Device();
        try {
            PreparedStatement statement=connection.prepareStatement(""+
                    "SELECT * FROM devices where id=?");
            statement.setLong(1,id);
            ResultSet resultSet=statement.executeQuery();
            while(resultSet.next()){
                Long id1=resultSet.getLong("id");
                String model=resultSet.getString("model");
                int price=resultSet.getInt("price");
                int count=resultSet.getInt("count1");
                String cpu=resultSet.getString("cpu");
                int ram=resultSet.getInt("ram");
                String gt=resultSet.getString("device_type");
                device=new Device(id1, model, price, count, cpu, ram, gt);
            }
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return device;
    }
    public static void updateDeviceBuy(Long id, int newcount, int sold){
        try {
            PreparedStatement statement=connection.prepareStatement("UPDATE devices set count1=?, sold=? WHERE id=?");
            statement.setInt(1, newcount);
            statement.setInt(2,sold);
            statement.setLong(3, id);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    public static void editDevice(Device device){
        try {
            PreparedStatement statement=connection.prepareStatement(""+
                    " UPDATE devices set model=?,price=?,count1=?,cpu=?,ram=?,device_type=?"+
                    " WHERE id=?");
            statement.setString(1,device.getModel());
            statement.setInt(2,device.getPrice());
            statement.setInt(3,device.getCount());
            statement.setString(4,device.getCpu());
            statement.setInt(5,device.getRam());
            statement.setString(6,device.getDevice_type());
            statement.setLong(7,device.getId());
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void deleteDevice(Long id){
        try {
            PreparedStatement statement=connection.prepareStatement("DELETE FROM devices WHERE id=? ");
            statement.setLong(1,id);
            statement.executeUpdate();
            statement.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static ArrayList<UserBuy> getAllGoods(Long user_id){
        ArrayList<UserBuy> userBuys=new ArrayList<>();
        try {
            PreparedStatement statement=connection.prepareStatement(""+
                    "SELECT * FROM users_buy WHERE user_id=?");
            statement.setLong(1, user_id);
            ResultSet resultSet=statement.executeQuery();
            while(resultSet.next()){
                Long id=resultSet.getLong("id");
                Long user_id1=resultSet.getLong("user_id");
                String good_type=resultSet.getString("good_type");
                int count=resultSet.getInt("count1");
                int totalsum=resultSet.getInt("totalsum");

                UserBuy userBuy=new UserBuy(id, user_id1, good_type, count, totalsum);
                userBuys.add(userBuy);
            }
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userBuys;
    }
}

