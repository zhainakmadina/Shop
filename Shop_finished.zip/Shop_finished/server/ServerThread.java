package Shop.server;

import Shop.data.Device;
import Shop.data.Packet;
import Shop.data.User;
import Shop.data.UserBuy;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class ServerThread extends Thread {
    private Socket socket;

    public ServerThread(Socket socket) {
        this.socket = socket;
    }

    public void run(){
        try {
            ObjectOutputStream oos=new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream ois=new ObjectInputStream(socket.getInputStream());
            while(true){
                Packet packet=(Packet)ois.readObject();
                if(packet.getCode().equals("ADD_USER")){
                    User user=(User)packet.getData();
                    ServerApp.addUser(user);
                }
                else if(packet.getCode().equals("AUTH")){
                    User user=(User)packet.getData();
                    User response=ServerApp.getUser(user.getLogin(), user.getPassword());
                    Packet packet1=new Packet("AUTH", response);
                    oos.writeObject(packet1);
                }
                else if(packet.getCode().equals("ADD_DEVICE")){
                    Device device=(Device)packet.getData();
                    ServerApp.addDevice(device);
                }
                else if(packet.getCode().equals("LIST_DEVICES")){
                    ArrayList<Device> devices=ServerApp.getAllDevices();
                    Packet packet1=new Packet("LIST_DEVICES", devices);
                    oos.writeObject(packet1);
                }
                else if(packet.getCode().equals("EDIT_DEVICE")){
                    Device device=(Device)packet.getData();
                    ServerApp.editDevice(device);
                }
                else if(packet.getCode().equals("DELETE_DEVICE")){
                    Device device=(Device)packet.getData();
                    ServerApp.deleteDevice(device.getId());
                }
                else if(packet.getCode().equals("BUY_DEVICE")){
                    UserBuy userBuy=(UserBuy)packet.getData();
                    ServerApp.addUserBuy(userBuy);
                }
                else if(packet.getCode().equals("EDIT_DEVICE_BUY")){
                    Device device=(Device)packet.getData();
                    Device frDB=ServerApp.getDevice(device.getId());
                    int newcount=frDB.getCount()-device.getCount();
                    ServerApp.updateDeviceBuy(device.getId(), newcount, device.getCount());
                }
                else if(packet.getCode().equals("LIST_USER_GOODS")){
                    UserBuy userBuy=(UserBuy)packet.getData();
                    ArrayList<UserBuy> userBuys=ServerApp.getAllGoods(userBuy.getUser_id());
                    Packet packet1=new Packet("LIST_USER_GOODS", userBuys);
                    oos.writeObject(packet1);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
