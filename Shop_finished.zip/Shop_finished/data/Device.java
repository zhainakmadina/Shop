package Shop.data;

import java.io.Serializable;

public class Device extends Good implements Serializable {
    private String cpu;
    private int ram;
    private String device_type;

    public Device() {
    }

    public Device(Long id, String model, int price, int count, String cpu, int ram, String device_type) {
        super(id, model, price, count);
        this.cpu = cpu;
        this.ram = ram;
        this.device_type = device_type;
    }

    public Device(Long id, String model, int price, int count, int sold, String cpu, int ram, String device_type) {
        super(id, model, price, count, sold);
        this.cpu = cpu;
        this.ram = ram;
        this.device_type = device_type;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        this.ram = ram;
    }

    public String getDevice_type() {
        return device_type;
    }

    public void setDevice_type(String device_type) {
        this.device_type = device_type;
    }
    public String showDetails(){
        return getCpu()+" "+getRam();
    }
}
