-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Апр 27 2020 г., 15:19
-- Версия сервера: 10.1.36-MariaDB
-- Версия PHP: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `shop_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `devices`
--

CREATE TABLE `devices` (
  `id` int(11) NOT NULL,
  `model` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `count1` int(11) NOT NULL,
  `cpu` varchar(255) NOT NULL,
  `ram` int(11) NOT NULL,
  `device_type` varchar(255) NOT NULL,
  `sold` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `devices`
--

INSERT INTO `devices` (`id`, `model`, `price`, `count1`, `cpu`, `ram`, `device_type`, `sold`) VALUES
(3, 'fdf', 12, 11, 'dfd', 12, 'laptop', 1),
(4, 'bbb', 23, 22, 'fff', 12, 'laptop', 1),
(5, 'hhh', 700, 10, 'cccc', 1212, 'tablet', 5),
(6, 'bbb', 23, 23, 'fff', 12, 'laptop', 0),
(8, 'bbb', 23, 23, 'fff', 12, 'laptop', 0),
(10, 'bbb', 23, 13, 'fff', 12, 'laptop', 10),
(11, 'bbb', 23, 23, 'fff', 12, 'laptop', 0),
(12, 'bbb', 23, 23, 'fff', 12, 'laptop', 0),
(13, 'musa', 23, 18, 'fff', 12, 'laptop', 5),
(14, 'arman', 23, 23, 'fff', 12, 'laptop', 0),
(15, 'Sultan', 23, 20, 'coreeee', 12, 'laptop', 3),
(16, 'Sultan', 11111, 20, 'coreeee', 12, 'laptop', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `role` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `fullname`, `role`) VALUES
(1, 'admin', 'admin', 'Administrator', 1),
(2, 'musa', '123', 'Uatbayev Musa', 2),
(3, 'dias', 'dias123', 'Mr.Dias', 2),
(4, 'erik', '789456', 'Erik Utemuratov', 2),
(5, 'Beka', '456456', 'Beka', 2),
(6, 'amina', '123456', 'Bolysova Amina', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `users_buy`
--

CREATE TABLE `users_buy` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `good_type` varchar(255) NOT NULL,
  `count1` int(11) NOT NULL,
  `totalsum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users_buy`
--

INSERT INTO `users_buy` (`id`, `user_id`, `good_type`, `count1`, `totalsum`) VALUES
(1, 6, 'laptop', 4, 92),
(2, 6, 'tablet', 3, 2100),
(3, 6, 'laptop', 10, 230),
(4, 6, 'laptop', 1, 11111),
(5, 6, 'laptop', 2, 22222),
(6, 6, 'tablet', 5, 3500),
(7, 6, 'tablet', 5, 3500),
(8, 6, 'laptop', 5, 115),
(9, 6, 'laptop', 1, 23),
(10, 6, 'laptop', 1, 12),
(11, 6, 'laptop', 3, 69);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users_buy`
--
ALTER TABLE `users_buy`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `devices`
--
ALTER TABLE `devices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `users_buy`
--
ALTER TABLE `users_buy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
